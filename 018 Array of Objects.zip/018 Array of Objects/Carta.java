public class Carta
{
	int valor;
	String identificador;
	
	public Carta(int v, String i)
	{
		this.valor = v;
		this.identificador = i;
	}
}